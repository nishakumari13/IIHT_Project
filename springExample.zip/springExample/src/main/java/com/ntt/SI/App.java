package com.ntt.SI;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	ApplicationContext applicationContext=new ClassPathXmlApplicationContext("simple.xml");
		simple  s1=(simple)applicationContext.getBean("simpleinterest");
		//System.out.println(a1.getNames().get(0));//gives 1st index value
		
		
		System.out.println(s1.getP());
        System.out.println(s1.getR());
        System.out.println(s1.getT());
        s1.calc();
        
    }
}
