package com.ntt.sp;

public class security {
	// Prepare the information we'd like in our access control entry (ACE)
	ObjectIdentity oi = new ObjectIdentityImpl(Foo.class, new Long(44));
	Sid sid = new PrincipalSid("Samantha");
	Permission p = BasePermission.ADMINISTRATION;

	// Create or update the relevant ACL
	MutableAcl acl = null;
	try {
	  acl = (MutableAcl) aclService.readAclById(oi);
	} catch (NotFoundException nfe) {
	  acl = aclService.createAcl(oi);
	}

	// Now grant some permissions via an access control entry (ACE)
	acl.insertAce(acl.getEntries().length, p, sid, true);
	aclService.updateAcl(acl);
}
